/* eslint-disable no-undef, no-unused-vars */
const EHFamily = {}
EHFamily.Rupiah = {
  /**
   * Uang menjadi fixed
   * @param {string} angka Harus string karena ada fungsi String.replace masalahnya
   * @param {string} [prefix] Prefix uang, kosongkan kalau mau tetap rupiah
   */
  format: (angka, prefix) => {
    var numberString = angka.replace(/[^,\d]/g, '').toString()
    var split = numberString.split(',')
    var sisa = split[0].length % 3
    var rupiah = split[0].substr(0, sisa)
    var ribuan = split[0].substr(sisa).match(/\d{3}/gi)
    if (ribuan) {
      separator = sisa ? '.' : ''
      rupiah += separator + ribuan.join('.')
    }
    rupiah = split[1] !== undefined ? rupiah + ',' + split[1] : rupiah
    return typeof prefix !== 'undefined' ? rupiah : (rupiah ? 'Rp. ' + rupiah : '')
  },
  /**
   * Uang yang sudah dikasi model dikasi jadi angka biasa
   * @param {string} angka Harus string karena ada fungsi String.replace masalahnya
   * @param {string} [prefix] Prefix uang, kosongkan kalau mau tetap rupiah
   */
  original: (angka, prefix) => {
    const p = typeof prefix === 'undefined' ? 'Rp. ' : prefix
    return `${angka}`.split(p)[1].split('.').join('')
  }
}
