/* eslint-disable no-undef, no-unused-vars */

const EHModalForm = {
  add (url) {
    $('.modal-form').modal('show')
    $('.modal-title').text('Tambah Data')
    $('.form').find('.form-control').each((index, element) => {
      const el = $(element)
      el.val('')
      el.removeAttr('disabled')
    })
    $('#method').val('post')
    $('.modal-submit').val('Simpan')
    $('.form').attr('action', url)
  },
  edit (ajaxURL, formURL) {
    $('.modal-form').modal('show')
    $('.modal-title').text('Ubah Data')
    $('.form').find('.form-control').each((index, element) => {
      const el = $(element)
      el.attr('disabled', 'true')
    })

    $.get(ajaxURL, function (data) {
      data = JSON.parse(data)
      // console.log(data)
      Object.keys(data).forEach(d => {
        $(`#${d}`).removeAttr('disabled')
        $(`#${d}`).val(data[d])
      })
    })
      .fail((err) => {
        console.log(err)
      })

    $('#method').val('put')
    $('.modal-submit').val('Edit')
    $('.form').attr('action', formURL)
  },
  delete (url, primaryID, id) {
    if (confirm('Apakah anda ingin menghapus data ini?')) {
      $('#method').val('delete')
      $('.form').attr('action', url)
      $(`#${primaryID}`).val(id)
      $('.form').submit()
    }
  },
  lockElement (disabled) {
    const index = EHModalForm.lockElementConfig
    const disa = typeof disabled === 'undefined' ? 'readonly' : 'disabled'
    if (typeof index === 'string') {
      $('#' + index).attr(disa, 'true')
    } else if (typeof index === 'undefined') {
      alert(
        '[EasyHack] Undefined LockFormElement string/array. Maybe you do not intialize \n' +
        'the variable in script tag.'
      )
    } else {
      index.forEach(i => {
        $('#' + i).attr(disa, 'true')
      })
    }
  }
}
